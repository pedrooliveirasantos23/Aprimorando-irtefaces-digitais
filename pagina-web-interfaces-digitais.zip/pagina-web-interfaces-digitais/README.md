# 🚀 Página web: aprimorando interfaces digitais

Projeto desenvolvido durante a unidade **Página web: aprimorando interfaces digitais** do programa **Start by Alura**.

**Instrutora:** [Giulliana Cestari](https://github.com/giullianacestari)

---

## 🎯 Objetivos da unidade

Ao finalizar este projeto, você terá praticado:

- ✅ Aprimorar a experiência do usuário (UX) em interfaces digitais
- ✅ Estruturar arquivos de um projeto web, diferenciando HTML, CSS e JavaScript
- ✅ Desenvolver layouts responsivos utilizando **Flexbox**
- ✅ Implementar funcionalidades interativas com JavaScript (troca de temas)
- ✅ Produzir conteúdo digital de forma colaborativa, considerando autoria e referências

---

## 🛠️ Tecnologias utilizadas

| Tecnologia   | Função                              |
|--------------|-------------------------------------|
| **HTML5**    | Estrutura semântica da página       |
| **CSS3**     | Estilização, Flexbox e variáveis    |
| **JavaScript** | Interatividade e troca de tema    |
| **Flexbox**  | Layouts flexíveis e responsivos     |

---

## 📁 Estrutura do projeto

```
pagina-web-interfaces-digitais/
├── index.html          # Estrutura HTML da página
├── css/
│   └── styles.css      # Estilos e layout (Flexbox + temas)
├── js/
│   └── script.js       # Funcionalidades interativas
├── assets/             # Pasta para imagens e recursos
└── README.md           # Este arquivo
```

---

## ✨ Funcionalidades

- **Layout responsivo** com Flexbox (mobile, tablet e desktop)
- **Troca de tema** claro / escuro com persistência no `localStorage`
- **Navegação suave** entre seções
- **Formulário de contato** com validação básica
- **Cards de projetos e habilidades** com hover effects
- **Design moderno** com foco em UX e acessibilidade

---

## ▶️ Como visualizar

1. Baixe ou clone este repositório
2. Abra o arquivo `index.html` no navegador
3. Ou use a extensão **Live Server** no VS Code para desenvolvimento

```bash
# Se quiser servir localmente com Python
python -m http.server 8000
```

Depois acesse: `http://localhost:8000`

---

## 🌙 Como funciona a troca de tema

O tema é controlado por **variáveis CSS** (`:root` e `[data-theme="dark"]`).

O JavaScript:

1. Verifica se existe um tema salvo no `localStorage`
2. Se não existir, respeita a preferência do sistema operacional
3. Ao clicar no botão ☀️/🌙, alterna o atributo `data-theme` no `<html>`
4. Salva a escolha do usuário para as próximas visitas

---

## 📚 Referências e autoria

- Unidade: **Página web: aprimorando interfaces digitais** — Start by Alura
- Instrutora: Giulliana Cestari
- Conceitos de UX, Flexbox e organização de projetos web
- Fonte: [Inter](https://fonts.google.com/specimen/Inter) (Google Fonts)

Este projeto foi criado para fins educacionais, respeitando as boas práticas de autoria e referências.

---

## 📄 Licença

Este projeto é de uso educacional. Sinta-se livre para estudar, modificar e compartilhar!

---

**Feito com 💚 durante o Start by Alura**
