/**
 * Página web: aprimorando interfaces digitais
 * Start by Alura - Unidade prática
 *
 * Funcionalidades:
 * - Troca de tema (claro / escuro)
 * - Persistência do tema no localStorage
 * - Feedback no formulário de contato
 */

// ========================================
// TROCA DE TEMA
// ========================================

const themeToggle = document.getElementById('theme-toggle');
const htmlElement = document.documentElement;

/**
 * Aplica o tema salvo ou o tema do sistema
 */
function initTheme() {
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

  if (savedTheme) {
    htmlElement.setAttribute('data-theme', savedTheme);
  } else if (prefersDark) {
    htmlElement.setAttribute('data-theme', 'dark');
  } else {
    htmlElement.setAttribute('data-theme', 'light');
  }
}

/**
 * Alterna entre tema claro e escuro
 */
function toggleTheme() {
  const currentTheme = htmlElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

  htmlElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
}

// Inicializa o tema ao carregar a página
initTheme();

// Evento de clique no botão de tema
if (themeToggle) {
  themeToggle.addEventListener('click', toggleTheme);
}

// ========================================
// FORMULÁRIO DE CONTATO
// ========================================

const contactForm = document.getElementById('contact-form');

if (contactForm) {
  contactForm.addEventListener('submit', function (event) {
    event.preventDefault(); // Impede o envio real do formulário

    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const mensagem = document.getElementById('mensagem').value.trim();

    // Validação simples
    if (!nome || !email || !mensagem) {
      alert('Por favor, preencha todos os campos.');
      return;
    }

    // Feedback para o usuário (simulando envio)
    alert(`Obrigado, ${nome}! Sua mensagem foi recebida com sucesso.\n\nEste é um formulário de demonstração do projeto da unidade.`);

    // Limpa o formulário
    contactForm.reset();
  });
}

// ========================================
// NAVEGAÇÃO SUAVE (já coberta pelo CSS scroll-behavior)
// ========================================

// Destaca o link ativo conforme o scroll (melhoria de UX)
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav__link');

function highlightNavOnScroll() {
  const scrollY = window.pageYOffset;

  sections.forEach((section) => {
    const sectionHeight = section.offsetHeight;
    const sectionTop = section.offsetTop - 100;
    const sectionId = section.getAttribute('id');

    if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
      navLinks.forEach((link) => {
        link.classList.remove('nav__link--active');
        if (link.getAttribute('href') === `#${sectionId}`) {
          link.classList.add('nav__link--active');
        }
      });
    }
  });
}

window.addEventListener('scroll', highlightNavOnScroll);

// Estilo extra para o link ativo (pode ser expandido no CSS)
const style = document.createElement('style');
style.textContent = `
  .nav__link--active {
    color: var(--cor-primaria) !important;
    font-weight: 600;
  }
`;
document.head.appendChild(style);

console.log('🚀 Projeto carregado com sucesso! Unidade: Página web - aprimorando interfaces digitais');
